const express = require('express'); // must install
const app = express();
const morgan = require('morgan'); //must install
const productRoutes = require('./api/routes/products');
const orderRoutes = require('./api/routes/orders');
const basicAuth = require('express-basic-auth');

// authentication
app.use(basicAuth({

  users: {"cedric": "Buff@lo1"}

}));

app.use(morgan('dev'));
// routes should handle request
app.use('/products', productRoutes);
app.use('/orders', orderRoutes);
app.use((req, res, next) => {
  const error = new Error('Not Found');
  error.status = 404;
  next(error);
})

app.use((error, req, res, next) => {

  res.status(error.status || 500);
  res.json({
      error:{
        message: error.message
      }

  });

})
module.exports = app;
