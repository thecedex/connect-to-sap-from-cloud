const express = require('express'); // must instal
const router = express.Router();

// for local
//const dotenv = require('dotenv');
//dotenv.config();
router.get('/', (req, res, next) => {

  res.status(200).json({

    message: 'Orders were fetched'

  });

});

router.post('/', (req, res, next) => {

  res.status(201).json({

    message: 'Orders were created'

  });

});

router.get('/:partnerId', (req, res, next) => {
  const https = require('https');
// for local
//  const axios = require('axios');

// for sap cloud
  const SapCfAxios = require('sap-cf-axios').default;
  const axios = SapCfAxios("DD1_CLONE");

	const matchesApiKey = (authorizationHeader) => {
		const clientKey = (authorizationHeader || '').replace('ApiKey ', '');
		return clientKey === process.env.API_KEY;
	}


	if (!matchesApiKey(req.headers.api_key)) {
		res.status(403).json({
			error: 'Forbidden'
		});
		return;
	}

// for local
//  var webUrl = 'https://dd1.sap-deliveryhero.com/';
//  var path = 'sap/opu/odata/sap/YORDERS_SRV/OrdersSet';

// for sap cloud
  var webUrl = '...'
  var path = '/OrdersSet/';

// for all
  var filter = '?$filter=BusinessPartner%20eq%20%27' + req.params.partnerId +
               '%27';

  console.log( 'Path ' + path + filter );
  // to access this url I need to put basic auth.

  var request = require('request'); // must instal

  const getOrders = async () => {
    try {
// for sap cloud
        url =  path + filter;
// for local
//      username = process.env.SAP_USER,
//      password = process.env.SAP_PASSWORD,
//      url =  webUrl + path + filter, // for local
//      auth = "Basic " + new Buffer(username + ":" + password).
//      toString("base64");

      return await axios({  method : "get",
                            url : url,
                            headers  : { //'Authorization' : auth, // for local
                                      'Accept' : 'application/json'} } )
//      return axios.get('https://dog.ceo/api/breeds/list/all')
    } catch (error) {
        res.status(400).json({ error : '400' , message : error.message});
        return;
    }
  }


  const ordersProc = async () => {
      const orders = await getOrders();

      if (orders.data) {
        res.status(200).json(orders.data.d);
    }

  }

  ordersProc();


});

router.delete('/:orderId', (req, res, next) => {

  res.status(200).json({

    message: 'Order Deleted',
    orderId: req.params.orderId

  });


});

module.exports = router;
